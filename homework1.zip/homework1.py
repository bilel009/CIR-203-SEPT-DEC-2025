# Admission Number: CIM/00090/024
# CIR 203 – Practical Homework 1
# Student: Bill Lelenguya
# Course: Data Structures and Algorithms
# Homework 1 Solutions

import numpy as np

# ------------------ EXERCISE 1: NumPy Arrays ------------------

# 1. 2D array for 4 branches over 6 months
transactions = np.array([
    [1200, 1500, 1600, 1700, 1400, 1550],
    [1000, 1100, 1050, 1200, 1300, 1250],
    [1800, 1750, 1900, 2000, 1950, 2100],
    [900, 950, 1000, 1100, 1150, 1200]
])

print("\n--- Exercise 1 Output ---")
print("Transaction Table:\n", transactions)

# 2. Total transactions per branch
total_per_branch = np.sum(transactions, axis=1)
print("Total per branch:", total_per_branch)

# 3. Branch with highest total
highest_branch = np.argmax(total_per_branch) + 1
print("Branch with highest transactions:", highest_branch)

# 4. Average monthly transaction across branches
average_monthly = np.mean(transactions)
print("Average monthly transaction:", average_monthly)

# 5. Reshape array (3x8)
reshaped = transactions.reshape(3, 8)
print("Reshaped Array (3x8):\n", reshaped)

# ------------------ EXERCISE 2: Lists ------------------

print("\n--- Exercise 2 Output ---")

# 1. List of 10 routes
routes = [
    "Nairobi-West", "Kitale-Down", "Nakuru-North", "Mombasa-Line",
    "Nyeri-South", "Kisumu-Lake", "Nandi-Hills", "Narok-Highway",
    "Eldoret-Town", "Naivasha-Road"
]

# 2. Append and remove
routes.append("Thika-Superhighway")
routes.remove("Kitale-Down")

# 3. Sort and reverse
routes.sort()
routes.reverse()

print("Updated Routes:", routes)

# 4. Count routes starting with N
count_n = sum([1 for r in routes if r.startswith("N")])
print("Routes starting with N:", count_n)

# 5. List comprehension -> routes longer than 10 characters
long_routes = [r for r in routes if len(r) > 10]
print("Long routes:", long_routes)

# ------------------ EXERCISE 3: Tuples ------------------

print("\n--- Exercise 3 Output ---")

# 1. Patient tuple
patient = ("John Doe", 45, "120/80", 72)

# 2. Access age and heart rate
print("Age:", patient[1])
print("Heart Rate:", patient[3])

# 3. Why tuples?
print("Tuples are immutable, making them safer for storing fixed medical vitals.")

# 4. Convert -> update -> convert back
patient_list = list(patient)
patient_list[3] = 78
patient = tuple(patient_list)
print("Updated patient record:", patient)

# 5. Tuple of 5 patients + extract names
patients = (
    ("John Doe", 45, "120/80", 78),
    ("Mary Jane", 30, "110/70", 85),
    ("Peter Kim", 55, "130/85", 90),
    ("Sarah Lee", 25, "115/75", 76),
    ("Brian Otieno", 60, "140/90", 95)
)

names = [p[0] for p in patients]
print("Patient names:", names)

# ------------------ EXERCISE 4: Dictionaries ------------------

print("\n--- Exercise 4 Output ---")

# 1. Product inventory
inventory = {
    "Laptop": 15,
    "Mouse": 50,
    "Keyboard": 25,
    "Monitor": 8,
    "Speaker": 12
}

# 2. Add and update
inventory["USB Cable"] = 40
inventory["Monitor"] = 10

# 3. Function: stock < 10
def low_stock(inv):
    return {k: v for k, v in inv.items() if v < 10}

print("Low stock items:", low_stock(inventory))

# 4. Delete discontinued product
del inventory["Speaker"]
print("Updated inventory:", inventory)

# 5. Loop through items
for product, qty in inventory.items():
    print(product, "->", qty)
